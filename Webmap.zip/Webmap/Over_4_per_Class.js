var three = {
"type": "FeatureCollection",
"name": "Over_4_per_Class",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "space1": "1008_01_105", "space2": "5980_01_192", "Count": 6, "room1": "EEB  105", "room2": "PCAR 192" }, "geometry": { "type": "LineString", "coordinates": [ [ -122.306837903305762, 47.653554303013422 ], [ -122.307597015106282, 47.656229331915547 ], [ -122.308356126906787, 47.658904223780731 ] ] } },
{ "type": "Feature", "properties": { "space1": "1008_01_105", "space2": "5980_01_192", "Count": 6, "room1": "EEB  105", "room2": "PCAR 192" }, "geometry": { "type": "LineString", "coordinates": [ [ -122.306837903305762, 47.653554303013422 ], [ -122.307597015106282, 47.656229331915547 ], [ -122.308356126906787, 47.658904223780731 ] ] } },
{ "type": "Feature", "properties": { "space1": "1276_01_120", "space2": "1351_0G_008", "Count": 5, "room1": "KNE  120", "room2": "AND  008" }, "geometry": { "type": "LineString", "coordinates": [ [ -122.309086473944248, 47.656675032251414 ], [ -122.308186973209402, 47.654197739898798 ], [ -122.307287472474613, 47.651720330016616 ] ] } },
{ "type": "Feature", "properties": { "space1": "1306_01_A102", "space2": "1356_01_101", "Count": 4, "room1": "PAA A102", "room2": "THO  101" }, "geometry": { "type": "LineString", "coordinates": [ [ -122.310718064516834, 47.653077660598271 ], [ -122.308378804893792, 47.654878579601757 ], [ -122.306039545270721, 47.656679436496063 ] ] } },
{ "type": "Feature", "properties": { "space1": "1306_01_A102", "space2": "1356_01_101", "Count": 4, "room1": "PAA A102", "room2": "THO  101" }, "geometry": { "type": "LineString", "coordinates": [ [ -122.310718064516834, 47.653077660598271 ], [ -122.308378804893792, 47.654878579601757 ], [ -122.306039545270721, 47.656679436496063 ] ] } },
{ "type": "Feature", "properties": { "space1": "1351_02_223", "space2": "1276_01_130", "Count": 6, "room1": "AND  223", "room2": "KNE  130" }, "geometry": { "type": "LineString", "coordinates": [ [ -122.307807460429643, 47.651735437513054 ], [ -122.308591484331487, 47.654237541268444 ], [ -122.309375508233316, 47.656739525139514 ] ] } }
]
};
